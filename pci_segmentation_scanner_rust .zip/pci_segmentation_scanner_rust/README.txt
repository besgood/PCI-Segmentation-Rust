PCI Segmentation Scanner - Rust Version
========================================

This is a fully-featured Rust-based PCI segmentation testing tool.

## Features

- Nmap or Masscan support
- TCP/UDP scanning
- Batch scanning via host file
- Output saved with timestamps
- Safety prompt for UDP scanning with Masscan

## Build Instructions

1. Install Rust:
   https://www.rust-lang.org/tools/install

2. Extract this archive:
   $ unzip pci_segmentation_scanner_rust.zip
   $ cd pci_segmentation_scanner_rust

3. Build:
   $ cargo build --release

4. Run:
   $ ./target/release/pci_segmentation_scanner_rust --hostfile targets.txt --ports 1-1000 --protocol tcp --tool nmap --output pci_scan